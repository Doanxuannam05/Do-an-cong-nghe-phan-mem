/**
 * /api/conversations – Chat Patient ↔ Doctor (phòng chat gắn với booking đã xác nhận).
 * Real-time: NEW_MESSAGE, TYPING, MESSAGE_READ qua SSE. Chỉ thành viên mới đọc/gửi được.
 */
const { z } = require('zod')
const { createRouter, finalize, ah, HttpError, rateLimit } = require('../lib/http')
const { q, one } = require('../lib/db')
const { requireAuth } = require('../lib/auth')
const events = require('../lib/events')
const directory = require('../lib/directory')

const router = createRouter()
router.use(requireAuth)

// cache thành viên phòng chat (tránh truy vấn khi gửi "đang gõ…")
const members = new Map()
const remember = (cid, ids) => members.set(Number(cid), ids.map(Number))

router.get('/', ah(async (req, res) => {
  const rows = await q(
    `SELECT c.id, c.booking_id, c.last_message_at, b.code, b.status AS booking_status, b.consultation_type,
            o.user_id AS other_user_id, ou.full_name AS other_name, ou.role AS other_role, ou.avatar AS other_avatar,
            (SELECT row_to_json(m) FROM (SELECT content, type, sender_id, created_at FROM messages WHERE conversation_id = c.id ORDER BY created_at DESC LIMIT 1) m) AS last_message,
            (SELECT count(*)::int FROM messages m WHERE m.conversation_id = c.id AND m.sender_id IS DISTINCT FROM $1 AND m.type = 'TEXT' AND m.created_at > COALESCE(me.last_read_at, 'epoch')) AS unread
     FROM participants me JOIN conversations c ON c.id = me.conversation_id JOIN bookings b ON b.id = c.booking_id
     JOIN participants o ON o.conversation_id = c.id AND o.user_id <> $1 JOIN users ou ON ou.id = o.user_id
     WHERE me.user_id = $1 ORDER BY c.last_message_at DESC NULLS LAST LIMIT 50`,
    [req.user.id],
  )
  for (const r of rows) remember(r.id, [req.user.id, r.other_user_id])
  res.json(rows.map((r) => ({ ...r, other_online: events.isOnline(r.other_user_id) })))
}))

router.get('/:id/messages', ah(async (req, res) => {
  const id = z.coerce.number().int().positive().parse(req.params.id)
  const before = req.query.before ? new Date(String(req.query.before)) : null
  const row = await one(
    `SELECT (SELECT json_agg(user_id) FROM participants WHERE conversation_id = $1) AS members,
            (SELECT json_agg(m ORDER BY m.created_at) FROM (
               SELECT id, sender_id, type, content, created_at FROM messages WHERE conversation_id = $1 AND ($3::timestamptz IS NULL OR created_at < $3)
               ORDER BY created_at DESC LIMIT 100) m) AS messages,
            (SELECT json_agg(json_build_object('user_id', p.user_id, 'last_read_at', p.last_read_at, 'full_name', u.full_name, 'role', u.role))
               FROM participants p JOIN users u ON u.id = p.user_id WHERE p.conversation_id = $1) AS participants,
            (SELECT row_to_json(b) FROM (SELECT b.id, b.code, b.status, b.consultation_type FROM bookings b JOIN conversations c ON c.booking_id = b.id WHERE c.id = $1) b) AS booking`,
    [id, req.user.id, before],
  )
  if (!(row.members || []).includes(req.user.id)) throw new HttpError(403, 'Bạn không thuộc cuộc trò chuyện này')
  remember(id, row.members)
  const participants = (row.participants || []).map((p) => ({ ...p, online: events.isOnline(p.user_id) }))
  res.json({ messages: row.messages || [], participants, booking: row.booking })
}))

router.post('/:id/messages', rateLimit({ key: 'msg', max: 60 }), ah(async (req, res) => {
  const id = z.coerce.number().int().positive().parse(req.params.id)
  const { content } = z.object({ content: z.string().trim().min(1, 'Tin nhắn trống').max(2000) }).parse(req.body)
  const known = members.get(id)
  const others = (known || []).filter((u) => u !== req.user.id)
  const offline = others.filter((u) => !events.isOnline(u))
  const row = await one(
    `WITH ok AS (SELECT 1 FROM participants WHERE conversation_id = $1 AND user_id = $2),
     m AS (INSERT INTO messages (conversation_id, sender_id, content) SELECT $1, $2, $3 FROM ok RETURNING *),
     c AS (UPDATE conversations SET last_message_at = now() WHERE id = $1 AND EXISTS (SELECT 1 FROM m)),
     r AS (UPDATE participants SET last_read_at = now() WHERE conversation_id = $1 AND user_id = $2 AND EXISTS (SELECT 1 FROM m)),
     n AS (INSERT INTO notifications (user_id, type, title, body, data)
           SELECT x::int, 'NEW_MESSAGE', 'Tin nhắn mới từ ' || $5, left($3, 120), jsonb_build_object('conversationId', $1::int)
           FROM m, unnest(string_to_array($4::text, ',')) x WHERE x <> '' RETURNING *)
     SELECT (SELECT row_to_json(m) FROM m) AS message, (SELECT json_agg(user_id) FROM participants WHERE conversation_id = $1) AS members,
            (SELECT json_agg(n) FROM n) AS notifications,
            (SELECT b.id FROM conversations c JOIN bookings b ON b.id = c.booking_id WHERE c.id = $1) AS booking_id`,
    [id, req.user.id, content, offline.join(','), req.user.name],
  )
  if (!row.message) throw new HttpError(403, 'Bạn không thuộc cuộc trò chuyện này')
  remember(id, row.members)
  events.emit(row.members, 'NEW_MESSAGE', { conversationId: id, message: row.message })
  for (const n of row.notifications || []) events.emit(n.user_id, 'NOTIFICATION', n)

  // Bác sĩ mô phỏng tự trả lời
  if (req.user.role === 'PATIENT') {
    const other = row.members.find((u) => u !== req.user.id)
    const doc = directory.byUserId(other)
    if (doc?.isSimulated) require('../lib/bots').scheduleReply(id, doc.userId, row.message.id, req.user.id)
  }
  res.status(201).json(row.message)
}))

router.post('/:id/read', ah(async (req, res) => {
  const id = z.coerce.number().int().positive().parse(req.params.id)
  const r = await one(`UPDATE participants SET last_read_at = now() WHERE conversation_id = $1 AND user_id = $2 RETURNING last_read_at`, [id, req.user.id])
  if (!r) throw new HttpError(403, 'Bạn không thuộc cuộc trò chuyện này')
  const others = (members.get(id) || []).filter((u) => u !== req.user.id)
  events.emit(others, 'MESSAGE_READ', { conversationId: id, userId: req.user.id, readAt: r.last_read_at })
  res.json(r)
}))

/** "Đang gõ…" – không ghi DB */
router.post('/:id/typing', ah(async (req, res) => {
  const id = z.coerce.number().int().positive().parse(req.params.id)
  const list = members.get(id)
  if (!list || !list.includes(req.user.id)) return res.json({ ok: false })
  events.emit(list.filter((u) => u !== req.user.id), 'TYPING', { conversationId: id, userId: req.user.id })
  res.json({ ok: true })
}))

module.exports = finalize(router)
