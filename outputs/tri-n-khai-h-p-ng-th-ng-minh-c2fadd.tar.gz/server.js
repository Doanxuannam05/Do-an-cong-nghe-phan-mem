
const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
const { Cron } = require("croner");

const app = express();
const PORT = process.env.PORT || 3000;

// --- Middleware ---
app.use(cors());

// --- Body parsing ---
app.use(express.json());

// --- Health check ---
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok" });
});

// --- Auto-load backend routes from backend/routes/ ---
const routesDir = path.join(__dirname, "backend", "routes");
if (fs.existsSync(routesDir)) {
  fs.readdirSync(routesDir).forEach((file) => {
    if (!file.endsWith(".js")) return;
    const route = require(path.join(routesDir, file));
    if (typeof route === "function") {
      const routeName = file.replace(".js", "");
      app.use(`/api/${routeName}`, route);
      console.log(`\✓ Loaded route: /api/${routeName} from ${file}`);
    }
  });
}

// --- Cron job system ---
const _cronJobs = new Map();   // id -> Cron instance
const _cronState = new Map();  // id -> { lastRunAt, lastStatus, lastError }
let _cronTasks = [];           // in-memory copy of cron.json

function _loadCronJobs() {
  // Stop all existing cron jobs before reload
  for (const [, job] of _cronJobs) { try { job.stop(); } catch(_) {} }
  _cronJobs.clear();

  const cronPath = path.join(__dirname, "backend", "cron.json");
  if (!fs.existsSync(cronPath)) return;

  let tasks;
  try { tasks = JSON.parse(fs.readFileSync(cronPath, "utf-8")); }
  catch (e) { console.error("Failed to parse cron.json:", e.message); return; }
  if (!Array.isArray(tasks)) { console.error("cron.json must be an array"); return; }
  _cronTasks = tasks;

  for (const task of tasks) {
    if (!task.enabled) continue;
    const timeoutMs = (task.timeout || 300) * 1000;
    let handlerMod;
    try { handlerMod = require(path.join(__dirname, "backend", task.handler)); }
    catch (e) { console.error(`Failed to load cron handler ${task.handler}:`, e.message); continue; }
    if (typeof handlerMod.handler !== "function") { console.error(`Cron handler ${task.handler} does not export a handler function`); continue; }

    if (!_cronState.has(task.id)) {
      _cronState.set(task.id, { lastRunAt: null, lastStatus: null, lastError: null });
    }

    const job = new Cron(task.schedule, async () => {
      const state = _cronState.get(task.id);
      state.lastRunAt = new Date().toISOString();
      try {
        await Promise.race([
          Promise.resolve(handlerMod.handler()),
          new Promise((_, reject) => setTimeout(() => reject(new Error("Cron task timed out")), timeoutMs)),
        ]);
        state.lastStatus = "success";
        state.lastError = null;
        console.log(`Cron [${task.id}] ${task.name}: success`);
      } catch (e) {
        state.lastStatus = "error";
        state.lastError = e.message;
        console.error(`Cron [${task.id}] ${task.name}: error -`, e.message);
      }
    });
    _cronJobs.set(task.id, job);
    console.log(`\✓ Scheduled cron: [${task.id}] ${task.name} (${task.schedule})`);
  }
}

function _saveCronAndReload() {
  const cronPath = path.join(__dirname, "backend", "cron.json");
  const dir = path.dirname(cronPath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(cronPath, JSON.stringify(_cronTasks, null, 2));
  // Clear require cache for handler modules so reload picks up changes
  for (const task of _cronTasks) {
    try { delete require.cache[require.resolve(path.join(__dirname, "backend", task.handler))]; } catch(_) {}
  }
  _loadCronJobs();
}

function _validateCronInterval(schedule) {
  // Reject intervals shorter than 1 minute
  try {
    const job = new Cron(schedule, { paused: true }, () => {});
    const next1 = job.nextRun();
    const next2 = job.nextRuns(2)[1];
    job.stop();
    if (next1 && next2 && (next2 - next1) < 60000) return false;
  } catch(e) { return false; }
  return true;
}

// Auth middleware for cron routes
function _cronAuth(req, res, next) {
  const token = process.env.APP_TOKEN;
  if (!token) return next();
  const auth = req.headers.authorization;
  if (!auth || auth !== `Bearer ${token}`) return res.status(401).json({ error: "Unauthorized" });
  next();
}

// Cron CRUD routes
app.get("/api/cron", _cronAuth, (_req, res) => {
  const result = _cronTasks.map((t) => {
    const state = _cronState.get(t.id) || { lastRunAt: null, lastStatus: null, lastError: null };
    const job = _cronJobs.get(t.id);
    return { ...t, ...state, nextRun: job ? job.nextRun()?.toISOString() || null : null };
  });
  res.json(result);
});

app.post("/api/cron", _cronAuth, (req, res) => {
  const { id, name, schedule, handler, enabled, timeout } = req.body;
  if (!id || !name || !schedule || !handler) {
    return res.status(400).json({ error: "Missing required fields: id, name, schedule, handler" });
  }
  if (_cronTasks.some((t) => t.id === id)) {
    return res.status(409).json({ error: `Task with id '${id}' already exists` });
  }
  if (!_validateCronInterval(schedule)) {
    return res.status(400).json({ error: "Schedule interval must be at least 1 minute" });
  }
  const task = { id, name, schedule, handler, enabled: enabled !== false, timeout: timeout || 300 };
  _cronTasks.push(task);
  _saveCronAndReload();
  res.status(201).json(task);
});

app.patch("/api/cron/:id", _cronAuth, (req, res) => {
  const idx = _cronTasks.findIndex((t) => t.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: "Task not found" });
  if (req.body.schedule && !_validateCronInterval(req.body.schedule)) {
    return res.status(400).json({ error: "Schedule interval must be at least 1 minute" });
  }
  _cronTasks[idx] = { ..._cronTasks[idx], ...req.body, id: req.params.id };
  _saveCronAndReload();
  res.json(_cronTasks[idx]);
});

app.delete("/api/cron/:id", _cronAuth, (req, res) => {
  const idx = _cronTasks.findIndex((t) => t.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: "Task not found" });
  _cronTasks.splice(idx, 1);
  _saveCronAndReload();
  res.json({ ok: true });
});

app.post("/api/cron/:id/run", _cronAuth, async (req, res) => {
  const task = _cronTasks.find((t) => t.id === req.params.id);
  if (!task) return res.status(404).json({ error: "Task not found" });
  const timeoutMs = (task.timeout || 300) * 1000;
  let handlerMod;
  try { handlerMod = require(path.join(__dirname, "backend", task.handler)); }
  catch (e) { return res.status(500).json({ error: `Failed to load handler: ${e.message}` }); }
  if (typeof handlerMod.handler !== "function") return res.status(500).json({ error: "Handler does not export a handler function" });
  const state = _cronState.get(task.id) || { lastRunAt: null, lastStatus: null, lastError: null };
  state.lastRunAt = new Date().toISOString();
  _cronState.set(task.id, state);
  try {
    await Promise.race([
      Promise.resolve(handlerMod.handler()),
      new Promise((_, reject) => setTimeout(() => reject(new Error("Cron task timed out")), timeoutMs)),
    ]);
    state.lastStatus = "success";
    state.lastError = null;
    res.json({ status: "success", lastRunAt: state.lastRunAt });
  } catch (e) {
    state.lastStatus = "error";
    state.lastError = e.message;
    res.status(500).json({ status: "error", error: e.message, lastRunAt: state.lastRunAt });
  }
});

// Load cron jobs immediately after route loading
_loadCronJobs();

// --- App title: prefer LLM-generated APP_TITLE, fall back to formatted APP_NAME ---
const appTitle = process.env.APP_TITLE
  || (process.env.APP_NAME || "Surf App").replace(/[-_]/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());

// --- Default Surf favicon (served when project has no custom favicon) ---
const DEFAULT_FAVICON = Buffer.from(
  "AAABAAEAICAAAAEAIACoEAAAFgAAACgAAAAgAAAAQAAAAAEAIAAAAAAAABAAABMLAAATCwAAAAAAAAAAAACro3oA1tW/AKuidTKmnW+fnpRl3pOIWPSMgE/8hXlJ/oF0Rf+Ac0P/e24//3VnOf93aTr/d2o7/3NlN/9uYDP/aFou/2JTKP9eUCX/YFIn/2RVKv9lVin/Y1Qo/2NUKf9jUyj+YlEm/F9PJPRbSyLeWEggnlZGHzJhUjgAWEkiAJGFZQCon3BKo5ps2pyRYv+Shlb/in1N/4N2Rf98bz//d2o7/3dqOv92aTr/dGY4/3FjNP9sXjH/Z1kt/2JTKP9eUCX/X1Al/2JTKP9kVCj/ZFQp/2NTKP9hUSb/YFAm/11NI/9bSyL/WEgg/1ZGH/9TRB7/UkMd2k9AGkpcTiUAoZdoMqCVZdmYjF3/j4NT/4Z5SP98b0D/dWg5/3RnOP92aTr/dGY4/2xeMv9mWCz/ZFYq/2JUKf9gUSX/X1El/2JTJ/9kVSj/Y1Qo/2NUKP9jVCf/YlIm/19QJf9dTiT/W0si/1hIIP9TRBz/UEAb/04/Gf9KPBf/SDoV2UU3EzKZjl6ek4hX/4l9S/9+cUH/dmk5/3RnN/94azv/dmk6/21gMv9kVin/YFIm/19RJf9fUST/YVIm/2RVKP9nWCv/aFkr/2ZWKf9jUyb/YFEl/2BQJf9dTSP/Wkoh/1dIH/9URB3/T0AZ/0s8Fv9JOxb/RzgV/0M1E/9BMxH/QDIRnox/Td2BdEP/em08/3hrOv93ajn/eGs6/3BiNP9lVyn/Z1ou/21gNv9tYDb/a140/2ZYK/9oWSz/alst/2pbLP9pWiz/b2A2/21eNv9pWzL/XEwj/1RFHP9SQxv/Tz8Z/0s8F/9TRSP/Sz0c/0IzEf9AMhL/PjAQ/zwuD/87LQ/dfnFA9H5wP/98bz3/em07/3dqOP9vYTH/ZVco/5KJaf/U0MT/4+HZ/+bk3P/Au6f/alsu/2VWKP9hUiX/cWM7/7u0oP/g3dX/4+DZ/9/c0/98cVL/T0AY/0w9F/9IORX/jINt/9rX0P+8uKz/TUAj/zosDv86LQ//OSwP/zksD/SAcz/8e247/3VoNf9wYzH/a10s/2VXJv+Rh2X/8fDs/////////////////9PQw/9jVSn/XE0h/2NVLP/Ev7D//////////////////Pz7/4J4Xf9HOBL/RDUR/3pwVv/v7uv//////+zq5/9ZTjX/NyoM/zksD/85LA//OCwQ/HJlMv5tXy3/alwr/2pcK/9rXCr/hXlR/+Xj2///////+vr4/8K8qf+spIv/1dHF/4l+Xv9nWTP/r6iU//z8/P//////3tvV/5qSff+6taj/r6iZ/1RHKP9sYUj/393X///////5+fj/lo+A/zktEP83Kw7/NysP/zgsEP82Kg/+bWAu/21fLP9vYS//cWIw/3tuPv/X08T//////////v+/uKT/aFkr/1tLHP+bkXb/8O/r/+Xj3f/7+vn//////+jm4v9uYkf/PC0K/0s+H//Szsf/5ePf/+3s6f///////v7+/6ijmP84LBL/MiYK/zQoDf80KA3/NSkO/zQoDf9wYi//cGIu/29hLP9tXin/i39W//b18v//////0s6//25gNP9cTB7/VkYZ/4Z7XP/7+/r////////////19PL/hn1m/z8xDv88Lw7/PTES/8XCuf/////////////////DwLn/PzUd/ysgB/8qIAf/KyEI/y0jCv8vJAv/LyML/29hLP9uYCv/bF4q/2haJf+IfVT/+Pj2/+Th2f94a0T/WEga/1ZGGf9OPxP/e29Q//f39f///////Pz8/6Kbif9ENxX/PjEQ/zksDf84LA//u7eu////////////29nV/01FMf8mHAT/Jx4G/yceBv8oHgf/KB4H/ykfCP8rIQr/cGEs/21fKv9pWyf/ZFUi/39zTP/U0cX/hHlY/1RFGP9RQhf/XE4n/1hLJf9RQx//sq2e/+Xk3/+tp5j/Sz4e/z0vD/8/MhX/S0Am/zcrEf9pYU//19TQ/9LQzP9hWkn/JBsD/yUcBv80Kxb/KyIN/yYcBv8lHAb/Jx0H/ykfCf91ZjH/cWIt/2tbKP9jUyL/X1Aj/19SKP9PQRf/SjsS/3pwUv/a187/29nS/3VrUv9AMxL/T0Mm/z4yE/83Kgz/QjYa/6mjl//k4t//q6ac/zkvGP87MRz/OC8Z/yUcBv8jGgT/X1hI/8fFv/9QSDf/IhkD/yYdB/8nHgj/KB4I/3JjLf9sXSn/ZlYk/2BRIP9ZShz/UUIX/0k6Ef9mWjr/393X////////////vbmv/zktDv8yJwn/MSYJ/zEnDP+YkoT//Pz7///////29vX/X1dG/yccBf8nHQb/JBoF/0pCMP/b2dX/9fX0/1RMPP8hGAP/JhwH/ygeCf8pHwj/YVIh/1tMHv9VRhr/UUMX/00/Ff9JOxP/VUgm/8rGu//////////////////Ewbn/OCwQ/zEmCv8pHwX/dW9f//Tz8v////////////r6+f9jXEz/IhkD/yYcB/84Lxv/wb64///////y8fD/UUk4/yIZA/8lHAb/KB4J/ygfCf9QQhf/Tj8W/0o8FP9FNxH/QDMN/0U4Fv+tqJn//v7+///////t7On/5OLf/87Mxv8+Mxv/Kx8F/1tTQP/k4+D///////r5+f/e3dr/7Ovp/3dyZf8cEwD/KiAN/6Oflv/+/v7//////8C+uP80Kxf/JhwH/yYcB/8nHgj/Jx0H/0c6E/9GOBL/QTUP/z4yDv88MA//kYp4//n5+P//////3NrW/2FYQ/9EOSL/paCV/7Kupf+Nhnn/2dfT///////8+/v/mJOK/zgwHf9gWUr/xcO9/4qFev+opJz/+Pj3///////b2dX/TUQz/yUbBv8oHgj/KR8J/ygeCP8nHgf/QjUS/z4yD/86Lw7/NSoK/1RKMP/n5uL//////+3s6v9qYlD/Kx8G/yccA/9oYVH/+/v6/////////////////7Kvp/8wJhP/IRcD/ygfC//CwLr/////////////////7ezq/2hgUf8mHAb/KR4I/ykfCP8qIAn/KyEK/ywiC/87Lw3/OC0M/zYrDP8vJQf/XVU///X08//5+fj/hH9x/ywhCf8sIQr/JhsE/2RdTv/6+fn////////////OzMf/QTgl/yIZBP8iGQX/Jx4L/7+8tv////////////j49/+GgHP/LiMM/ysgCv8pHwj/KyAK/yshCf8vJAz/MiYO/zcsDf80KQv/MScK/ywiBv9bUz7/8/Lw/6Sglf8vJQ7/Jx0G/yUaBP8gFgD/Rj4t/+Lh3v//////4uHe/1VNPv8iGAP/IhkE/yAXAv8eFQH/lpKI///////9/f3/oZ2T/y8mEP8vJAz/LiMK/y4kC/8uIwv/LiML/zInDf82KhD/MygL/zAmCv8tJAj/KyEH/0I6Iv92cWD/Ni0X/yQbA/8zKxb/enRn/3x2av81LRr/V1BB/4mFev9TSzz/IRgE/yEYBP9TTDz/ioV6/1ZPP/80LBn/fHdq/3p0Z/8yKRX/Jx0G/z40Hf98dWX/ST4o/zAkC/8wJQz/MygO/zYqD/8tJAn/LCMI/ysiCP8qIQj/KSAH/yUcA/8mHQX/KyMM/6Gdk//9/f3//////5iTiv8iGAT/IBcC/yIYBf8hFwT/VE09/+Lh3v//////4uHe/0c/Lf8fFQD/IhkE/yUcBv8wJhD/p6KY//Py8f9fVkL/LiIJ/zAlC/8zJw3/MygM/ywjCP8rIgf/KiEH/ykgBv8pIAf/Jx8H/yUdBf+BfW//+Pj3////////////v7y2/yohDf8lHAj/IhkF/z82Jf/Oy8f////////////6+vn/ZF1N/yMZA/8mHAb/Jx0H/4R+cf/5+fj/9fTz/11UQP8tIgf/MSYL/zInC/81KQz/LSQJ/ysiCP8pIQb/KSAH/ygfB/8kGwP/ZF5N/+zs6v/////////////////DwLr/KyIN/yUbBv8wJxP/sq6n//////////////////v7+/9pYlL/JBoD/yYcBP9mX07/7ezq///////m5eL/TkUv/y8jCP8yJwv/MicK/zcrDP8sIwj+KyIH/ykgB/8oIAf/JRwE/09INf/b2dX///////j49/+opZz/i4Z7/8XDvf9jW0z/OjEe/5iTif/8+/v//////9nX0/+KhHj/sq6l/6Wglv9BNyL/XVVC/9va1v//////+fj3/4uFdf8zKAz/NCgL/zMoCv8zKAj/NysJ/i0kCfwtJAn/KiEH/ygfBv87Mxz/ysjC///////+/v7/o5+V/ywjDf8hFwH/eHNl/+zr6v/f3dr/+vn5///////l5OH/W1NB/yQaAv86MBr/zsvF/+Pi3//s6+n///////7+/v+nopb/OC0Q/zUpCv84Kwz/OCwM/zsuDP8/Mg78LyUK9C8lCv8sIwj/KSAF/01FL//p6Ob//////8C9tv86MRv/Jx4G/ycdBf9lXk7/+vr5////////////6Ofl/3NsXP8rIAj/LiML/zIoEP/Cv7j////////////8+/v/u7et/0M4Hf8zJwj/OSwM/z0vDv8+MQ3/QTMN/0c4EPQxKAvdMScK/y8mCf8tJAj/MScN/2dgTP99d2f/Qjoj/yogBv8pIAf/Jx4F/0E5JP9/emz/g31v/353af9SSjb/LiML/y8kC/8vJAv/MicN/3BoVf+LhHT/ioNz/3ZuWv9DNxv/NSkJ/zotDf8/Mg//QjQP/0U3EP9JOxL/UEEU3TQqC540Kgv/MykL/zEnCv8wJgr/LSMG/yshBf8sIwf/LiQK/y0jCf8rIgj/KSAG/yYcAv8mHQP/Jx0D/ysgBv8vJAr/NCgO/zQoDf81KQ3/NSkM/zYpC/83Kgv/OCsL/zksDf87Lg3/QDIO/0Q2EP9HORD/TT4U/1JCE/9WRhOeNSsLMjYrDNk1Kwz/MykL/zEnCv8wJwn/MCYJ/y4lCP8xJwr/NCgM/zAmCv8tJAj/LSMI/y0jCf8tIwj/LyQJ/zImC/83Kg7/Oi0Q/zsuEP87LxD/Oy8Q/zwvD/89MA//PjEO/0AzDf9DNQ7/RzgP/0w9EP9VRRX/WkoV2VxNFjI+MRQAOC0NSjgtDdo3LAz/NCoL/zMpC/8yKAr/MCcJ/zEnCv81Kgz/NSkM/zInC/8vJQj/LiQI/y8lCf8xJgr/NSkM/zksDv87Lg//Oy4P/zwvD/89MA//QDIQ/0EzEP9DNRD/RDYO/0k6EP9OPxL/U0QS/1tLFdpgUBdKUEANADowDABHQAAAOS4NMjgtDZ43LAzeNisM9DUqC/w0KQv+NCkL/zMpCv8zKAr/NCkL/zQpC/8zKAn/MicJ/zQpCv85LA3/Oy4P/zsuD/86LQ3/Oy4N/z4xDv9DNRH/RzkT/0o7FP5KOxL8Tj8S9FNDEt5YSBOfYVAYMoR/AABhUQ8AwAAAA4AAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgAAAAcAAAAM",
  "base64"
);

// --- Static assets with long-term caching ---
app.use(
  "/assets",
  express.static(path.join(__dirname, "dist/client/assets"), {
    maxAge: "1y",
    immutable: true,
  })
);

// Serve default favicon if project has none
const hasCustomFavicon = fs.existsSync(path.join(__dirname, "dist/client/favicon.ico"));
if (!hasCustomFavicon) {
  app.get("/favicon.ico", (_req, res) => {
    res.set({ "Content-Type": "image/x-icon", "Cache-Control": "public, max-age=86400" });
    res.send(DEFAULT_FAVICON);
  });
}

app.use(
  express.static(path.join(__dirname, "dist/client"), {
    index: false,
  })
);

// --- HTML catch-all ---
const rawTemplate = fs.readFileSync(
  path.join(__dirname, "dist/client/index.html"),
  "utf-8"
);
const template = rawTemplate.replace(/<title>[^<]*<\/title>/, `<title>${appTitle}</title>`);
const PLACEHOLDER_HTML = `<div data-surf-placeholder style="min-height:100vh;background:#ffffff"></div>`;

app.get("*", (req, res) => {
  const page = template.replace("<!--ssr-outlet-->", PLACEHOLDER_HTML);
  res.status(200).set({ "Content-Type": "text/html" }).send(page);
});

function startServer(retries = 10, delay = 1000) {
  const server = app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
  server.on("error", (err) => {
    if (err.code === "EADDRINUSE" && retries > 0) {
      console.log(`Port ${PORT} in use, retrying in ${delay}ms... (${retries} left)`);
      setTimeout(() => startServer(retries - 1, delay), delay);
    } else {
      console.error(`Failed to start server: ${err.message}`);
      process.exit(1);
    }
  });
}
startServer();
