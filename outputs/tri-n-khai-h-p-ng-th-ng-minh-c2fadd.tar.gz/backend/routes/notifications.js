/** /api/notifications – thông báo in-app */
const { z } = require('zod')
const { createRouter, finalize, ah } = require('../lib/http')
const { q, one } = require('../lib/db')
const { requireAuth } = require('../lib/auth')

const router = createRouter()
router.use(requireAuth)

router.get('/', ah(async (req, res) => {
  const row = await one(
    `SELECT (SELECT json_agg(n ORDER BY n.created_at DESC) FROM (SELECT id, type, title, body, data, read_at, created_at FROM notifications
              WHERE user_id = $1 AND type <> 'SYSTEM_SEEDED' ORDER BY created_at DESC LIMIT 40) n) AS items,
            (SELECT count(*)::int FROM notifications WHERE user_id = $1 AND read_at IS NULL AND type <> 'SYSTEM_SEEDED') AS unread`,
    [req.user.id],
  )
  res.json({ items: row.items || [], unread: row.unread })
}))

router.post('/read-all', ah(async (req, res) => {
  await q(`UPDATE notifications SET read_at = now() WHERE user_id = $1 AND read_at IS NULL`, [req.user.id])
  res.json({ ok: true })
}))

router.post('/:id/read', ah(async (req, res) => {
  const id = z.coerce.number().int().positive().parse(req.params.id)
  await q(`UPDATE notifications SET read_at = now() WHERE id = $1 AND user_id = $2`, [id, req.user.id])
  res.json({ ok: true })
}))

module.exports = finalize(router)
